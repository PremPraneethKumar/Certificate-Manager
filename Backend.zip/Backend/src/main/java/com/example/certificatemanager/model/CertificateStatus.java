package com.example.certificatemanager.model;

public enum CertificateStatus {
    ACTIVE,
    EXPIRED
}